<html>
    <link href="../css/loginstyle.css" rel='stylesheet' type='text/css' />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="App Loction Form,Login Forms,Sign up Forms,Registration Forms,News latter Forms,Elements"./>
    <script type="application/x-javascript"> 
        addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>



<div id="logGet">
    <div class="app-location">
        <h2>Welcome to GAME STOP</h2>
        <div class="line"><span></span></div>

        <form action="../controller/register2.php" method="post" id='submitform'>
            <input name="regemail" type="text" id="regemail" value="EMAIL"><br>   
            <input name="regpwd" type="password" id="regpwd" value="PASSWORD"><br>            
            <input name="regfn" type="text" id="regfn" value="FIRST NAME"><br>
            <input name="regln" type="text" id="regln" value="LAST NAME"><br>
            <div class="submit">
                <input type="submit" value="OK" ></div>

        </form>
    </div>   
</div>



</html>