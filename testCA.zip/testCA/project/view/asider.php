
<aside>
    <div id="sider">
        <h2>ACTIONS</h2>
        <ul>
            <li><a href="../controller/manage.php">Select Employees</a></li>
            <li><a href="../view/main_view_select.php">View Timesheets</a></li>
        </ul>
    </div>
</aside>
