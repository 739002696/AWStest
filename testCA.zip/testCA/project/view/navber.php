<!---Navigation --->
    <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
        <div class="container-fluid">
            <a class="nabar-brand" href="../view/home.php" ><img src="../img/logo.jpg" width="50" height ="50"></a>
            <butto class="navbar-toggler" type="button" data-toggle="collapse"
                   data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
            </butto> 
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="../view/home.php">Home</a>
                    </li>
                     <li class="nav-item">
                         <a class="nav-link" href="../view/gamelist.php">Game List</a>
                    </li>
                     <li class="nav-item">
                         <a class="nav-link" href="../view/order.php">Your Order</a>
                    </li>
                     <li class="nav-item">
                         <a class="nav-link" href="../view/updata_order.php">Updata Order</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="#">Home</a>
                    </li>    
                </ul>
            </div>
        </div>    
    </nav>