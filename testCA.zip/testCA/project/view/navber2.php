<!---Navigation --->
    <nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
        <div class="container-fluid">
            <a class="nabar-brand" href="../view/home.php" ><img src="../img/logo.jpg" width="50" height ="50"></a>
            <butto class="navbar-toggler" type="button" data-toggle="collapse"
                   data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
            </butto> 
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="../view/home.php">Home</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="../controller/manage.php">Select Employees</a>
                    </li>
                     <li class="nav-item">
                         <a class="nav-link" href="../view/main_view_select.php">View Timesheets</a>
                    </li>
  
                </ul>
            </div>
        </div>    
    </nav>

