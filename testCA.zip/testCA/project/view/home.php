
<html>
    <?php 
    include '../view/header.php'; ?>
    <body>
        <!---Navigation --->
        <?php include '../view/navber.php'; ?>
        <!--Image Slider -->
        <?php include '../view/imgSlider.php'; ?>
        <aside>     
         
        </aside>
    </body>
</html>
