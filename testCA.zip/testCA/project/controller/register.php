<html>
<form name = "reg1" method = "post" action = "reg.php">
register<br>
Email:
<input name="regemail" type="text" id="regemail"><br>
Password:
<input name="regpwd" type="password" id="regpwd"><br>
First Name:
<input name="regne" type="text" id="regfn"><br>

<input name="OK" type="submit" value="OK">
</form>
    </html>